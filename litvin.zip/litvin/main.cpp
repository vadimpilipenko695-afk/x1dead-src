#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <unistd.h>
#include <sys/mman.h>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <EGL/egl.h>
#include <GLES/gl.h>
#include <pthread.h>

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "x1dead", __VA_ARGS__)

#define O_GC_get_Instance 0x123C37C
#define O_GC_PlayerCtrl 0x200
#define O_PC_Team 0x49
#define O_Photon_GetRoom 0x18D80F0
#define O_Room_Props 0x18
#define O_Room_SetScore 0x1370124
#define O_Room_SetRound 0x136F798
#define O_Room_SetRc 0x13712A0
#define O_Room_SetTime 0x136F67C
#define O_Room_SetCust 0x1570F1C

uintptr_t base = 0;

extern "C" void menu_render(float width, float height);
extern "C" void menu_on_touch(float x, float y, bool down);
extern "C" bool menu_check_win();

typedef void* (*GetInstFn)(void*);
typedef void* (*GetRoomFn)(void*);
typedef void (*SetScoreFn)(void*, void*, int, int);
typedef void (*SetRoundFn)(void*, void*, int);
typedef void (*SetRcFn)(void*, void*, int);
typedef void (*SetTimeFn)(void*, void*, double);
typedef void (*SetCustFn)(void*, void*, void*, void*);

void apply_win() {
    if (!base) return;
    auto get_inst = (GetInstFn)(base + O_GC_get_Instance);
    auto get_room = (GetRoomFn)(base + O_Photon_GetRoom);
    auto set_score = (SetScoreFn)(base + O_Room_SetScore);
    auto set_round = (SetRoundFn)(base + O_Room_SetRound);
    auto set_rc    = (SetRcFn)(base + O_Room_SetRc);
    auto set_time  = (SetTimeFn)(base + O_Room_SetTime);
    auto set_cust  = (SetCustFn)(base + O_Room_SetCust);

    void* gc = get_inst(nullptr);
    if (!gc) return;
    void* lpc = *(void**)((uintptr_t)gc + O_GC_PlayerCtrl);
    if (!lpc) return;
    
    int my_team = *(uint8_t*)((uintptr_t)lpc + O_PC_Team);
    int enemy = (my_team == 1) ? 2 : 1;

    void* room = get_room(nullptr);
    if (!room) return;
    void* props = *(void**)((uintptr_t)room + O_Room_Props);
    if (!props) return;

    set_score(nullptr, props, my_team, 8);
    set_score(nullptr, props, enemy, 0);
    set_round(nullptr, props, 8);
    set_rc   (nullptr, props, 8);
    set_time (nullptr, props, 0.0);
    set_cust (room, props, nullptr, nullptr);
    LOG("AutoWin applied: 8:0");
}

void inline_hook(void* target, void* replace, void** origin) {
    if (!target) return;
    uintptr_t page_size = sysconf(_SC_PAGESIZE);
    uintptr_t page_start = (uintptr_t)target & ~(page_size - 1);
    if (mprotect((void*)page_start, page_size * 2, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) return;

    uint8_t* orig_code = (uint8_t*)malloc(16);
    memcpy(orig_code, target, 16);
    *origin = (void*)orig_code;

    uint32_t* p = (uint32_t*)target;
    p[0] = 0x58000050; 
    p[1] = 0xD61F0200;
    *(uint64_t*)((uintptr_t)target + 8) = (uint64_t)replace;
    __builtin___clear_cache((char*)target, (char*)target + 16);
}

typedef EGLBoolean (*SwapFn)(EGLDisplay, EGLSurface);
SwapFn orig_swap = nullptr;

EGLBoolean hk_swap(EGLDisplay d, EGLSurface s) {
    EGLint w = 0, h = 0;
    if (d && s) {
        eglQuerySurface(d, s, EGL_WIDTH, &w);
        eglQuerySurface(d, s, EGL_HEIGHT, &h);
    }
    
    if (w > 0 && h > 0) {
        menu_render((float)w, (float)h);
    }
    
    if (menu_check_win()) {
        apply_win();
    }
    
    return orig_swap ? orig_swap(d, s) : EGL_FALSE;
}

void* hack_thread(void*) {
    while (!base) {
        base = (uintptr_t)dlopen("libil2cpp.so", RTLD_LAZY | RTLD_NOLOAD);
        sleep(1);
    }
    LOG("il2cpp found!");

    void* h = dlopen("libEGL.so", RTLD_NOW);
    if (h) {
        void* target = dlsym(h, "eglSwapBuffers");
        if (target) {
            inline_hook(target, (void*)hk_swap, (void**)&orig_swap);
            LOG("EGL hooked!");
        }
    }
    return nullptr;
}

extern "C" jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOG("JNI_OnLoad called!");
    pthread_t t;
    if (pthread_create(&t, nullptr, hack_thread, nullptr) == 0)
        pthread_detach(t);
    return JNI_VERSION_1_6;
}