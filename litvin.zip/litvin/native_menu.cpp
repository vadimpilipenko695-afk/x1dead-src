#include <GLES/gl.h>
#include <android/bitmap.h>
#include <android/imagedecoder.h>
#include <android/log.h>
#include <cmath>
#include <cstdint>
#include <vector>
#include <android/input.h>
#include "embedded_assets.h"

namespace {

constexpr float kPanelLeft = 420.0f;
constexpr float kPanelTop = 60.0f;
constexpr float kPanelRight = 1530.0f;
constexpr float kPanelBottom = 772.0f;
bool g_visible = true;
bool g_assets_loaded = false;

// --- НАША КНОПКА ---
extern "C" bool g_win_requested = false;
float touch_x = 0, touch_y = 0;
bool is_touched = false;

struct Texture {
    GLuint id = 0;
};

Texture g_logo, g_close, g_toolbar_gear, g_users, g_target, g_folder, g_grid, g_gear, g_search;

struct Color {
    float r, g, b, a;
};

void set_color(Color color) {
    glColor4f(color.r, color.g, color.b, color.a);
}

void fill_rect(float left, float top, float right, float bottom, Color color) {
    const GLfloat vertices[] = { left, top, right, top, left, bottom, right, bottom };
    set_color(color);
    glVertexPointer(2, GL_FLOAT, 0, vertices);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

bool load_texture(const unsigned char* data, size_t size, Texture& texture) {
    AImageDecoder* decoder = nullptr;
    if (AImageDecoder_createFromBuffer(data, size, &decoder) != ANDROID_IMAGE_DECODER_SUCCESS) return false;
    const AImageDecoderHeaderInfo* header = AImageDecoder_getHeaderInfo(decoder);
    const int width = static_cast<int>(AImageDecoderHeaderInfo_getWidth(header));
    const int height = static_cast<int>(AImageDecoderHeaderInfo_getHeight(header));
    AImageDecoder_setAndroidBitmapFormat(decoder, ANDROID_BITMAP_FORMAT_RGBA_8888);
    const size_t stride = AImageDecoder_getMinimumStride(decoder);
    std::vector<unsigned char> pixels(stride * static_cast<size_t>(height));
    const int32_t status = AImageDecoder_decodeImage(decoder, pixels.data(), stride, pixels.size());
    AImageDecoder_delete(decoder);
    if (status != ANDROID_IMAGE_DECODER_SUCCESS) return false;

    glGenTextures(1, &texture.id);
    glBindTexture(GL_TEXTURE_2D, texture.id);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
    return true;
}

void load_assets() {
    if (g_assets_loaded) return;
    load_texture(embedded_assets::logo_png, sizeof(embedded_assets::logo_png), g_logo);
    load_texture(embedded_assets::close_png, sizeof(embedded_assets::close_png), g_close);
    load_texture(embedded_assets::toolbar_gear_png, sizeof(embedded_assets::toolbar_gear_png), g_toolbar_gear);
    load_texture(embedded_assets::users_png, sizeof(embedded_assets::users_png), g_users);
    load_texture(embedded_assets::target_png, sizeof(embedded_assets::target_png), g_target);
    load_texture(embedded_assets::folder_png, sizeof(embedded_assets::folder_png), g_folder);
    load_texture(embedded_assets::grid_png, sizeof(embedded_assets::grid_png), g_grid);
    load_texture(embedded_assets::gear_png, sizeof(embedded_assets::gear_png), g_gear);
    load_texture(embedded_assets::search_png, sizeof(embedded_assets::search_png), g_search);
    g_assets_loaded = true;
}

void draw_texture(const Texture& texture, float left, float top, float right, float bottom) {
    if (texture.id == 0) return;
    const GLfloat vertices[] = { left, top, right, top, left, bottom, right, bottom };
    const GLfloat coordinates[] = {0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f};
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture.id);
    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(2, GL_FLOAT, 0, coordinates);
    glVertexPointer(2, GL_FLOAT, 0, vertices);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisable(GL_TEXTURE_2D);
}

void fill_round_rect(float left, float top, float right, float bottom, float radius, Color color) {
    set_color(color);
    constexpr int segments = 12;
    GLfloat vertices[2 + 4 * (segments + 1) * 2];
    int vertex_count = 0;
    vertices[vertex_count++] = (left + right) * 0.5f;
    vertices[vertex_count++] = (top + bottom) * 0.5f;
    const float centers[4][2] = {
        {right - radius, top + radius}, {right - radius, bottom - radius},
        {left + radius, bottom - radius}, {left + radius, top + radius},
    };
    const float starts[4] = {-1.5707963f, 0.0f, 1.5707963f, 3.1415926f};
    for (int corner = 0; corner < 4; ++corner) {
        for (int segment = 0; segment <= segments; ++segment) {
            const float angle = starts[corner] + static_cast<float>(segment) / segments * 1.5707963f;
            vertices[vertex_count++] = centers[corner][0] + std::cos(angle) * radius;
            vertices[vertex_count++] = centers[corner][1] + std::sin(angle) * radius;
        }
    }
    glVertexPointer(2, GL_FLOAT, 0, vertices);
    glDrawArrays(GL_TRIANGLE_FAN, 0, vertex_count / 2);
}

void stroke_line(float x1, float y1, float x2, float y2, Color color, float width) {
    const GLfloat vertices[] = {x1, y1, x2, y2};
    set_color(color);
    glLineWidth(width);
    glVertexPointer(2, GL_FLOAT, 0, vertices);
    glDrawArrays(GL_LINES, 0, 2);
}

void draw_toggle(float center_y) {
    fill_round_rect(1416.0f, center_y - 19.0f, 1488.0f, center_y + 19.0f, 19.0f, {0.10f, 0.10f, 0.11f, 1.0f});
    fill_round_rect(1420.0f, center_y - 15.0f, 1450.0f, center_y + 15.0f, 15.0f, {0.97f, 0.97f, 0.97f, 1.0f});
}

void draw_sidebar_icon(float x, float y, int type, bool selected) {
    const Color color = selected ? Color{0.96f, 0.96f, 0.96f, 1.0f} : Color{0.40f, 0.40f, 0.42f, 1.0f};
    const float width = selected ? 3.0f : 2.0f;
    if (type == 0) {
        fill_round_rect(x - 11.0f, y - 4.0f, x + 11.0f, y + 7.0f, 5.0f, color);
        fill_round_rect(x - 5.0f, y - 14.0f, x + 5.0f, y - 4.0f, 5.0f, color);
    } else if (type == 1) {
        stroke_line(x - 14.0f, y, x + 14.0f, y, color, width);
        stroke_line(x, y - 14.0f, x, y + 14.0f, color, width);
        fill_round_rect(x - 5.0f, y - 5.0f, x + 5.0f, y + 5.0f, 5.0f, color);
    } else if (type == 2) {
        stroke_line(x - 12.0f, y - 8.0f, x + 12.0f, y - 8.0f, color, width);
        stroke_line(x - 9.0f, y + 8.0f, x + 9.0f, y + 8.0f, color, width);
        fill_round_rect(x - 9.0f, y - 3.0f, x + 9.0f, y + 13.0f, 8.0f, color);
    } else if (type == 3) {
        for (int row = 0; row < 2; ++row) {
            for (int column = 0; column < 2; ++column) {
                fill_round_rect(x - 14.0f + column * 16.0f, y - 13.0f + row * 16.0f, x - 3.0f + column * 16.0f, y - 2.0f + row * 16.0f, 3.0f, color);
            }
        }
    } else {
        fill_round_rect(x - 10.0f, y - 10.0f, x + 10.0f, y + 10.0f, 8.0f, color);
        fill_round_rect(x - 4.0f, y - 4.0f, x + 4.0f, y + 4.0f, 4.0f, {0.04f, 0.04f, 0.04f, 1.0f});
    }
}

void draw_menu(float width, float height) {
    if (!g_visible) return;
    glViewport(0, 0, static_cast<GLsizei>(width), static_cast<GLsizei>(height));
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnableClientState(GL_VERTEX_ARRAY);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrthof(0.0f, 1920.0f, 1080.0f, 0.0f, -1.0f, 1.0f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    load_assets();

    fill_rect(0.0f, 0.0f, 1920.0f, 1080.0f, {0.65f, 0.65f, 0.65f, 0.72f});
    fill_round_rect(kPanelLeft, kPanelTop, kPanelRight, kPanelBottom, 23.0f, {0.13f, 0.13f, 0.13f, 1.0f});
    fill_round_rect(kPanelLeft + 13.0f, kPanelTop + 13.0f, 560.0f, kPanelBottom - 13.0f, 17.0f, {0.035f, 0.035f, 0.035f, 1.0f});

    fill_rect(438.0f, 219.0f, 441.0f, 252.0f, {0.95f, 0.95f, 0.95f, 1.0f});
    draw_sidebar_icon(498.0f, 236.0f, 0, true);
    draw_sidebar_icon(498.0f, 348.0f, 1, false);
    draw_sidebar_icon(498.0f, 461.0f, 2, false);
    draw_sidebar_icon(498.0f, 574.0f, 3, false);
    draw_sidebar_icon(498.0f, 687.0f, 4, false);

    draw_texture(g_users, 470.0f, 212.0f, 526.0f, 260.0f);
    draw_texture(g_target, 469.0f, 324.0f, 527.0f, 372.0f);
    draw_texture(g_folder, 469.0f, 437.0f, 527.0f, 485.0f);
    draw_texture(g_grid, 469.0f, 550.0f, 527.0f, 600.0f);
    draw_texture(g_gear, 469.0f, 663.0f, 527.0f, 715.0f);

    fill_round_rect(573.0f, 73.0f, 630.0f, 130.0f, 12.0f, {0.035f, 0.035f, 0.035f, 1.0f});
    fill_round_rect(643.0f, 73.0f, 1378.0f, 130.0f, 12.0f, {0.035f, 0.035f, 0.035f, 1.0f});
    fill_round_rect(1390.0f, 73.0f, 1447.0f, 130.0f, 12.0f, {0.035f, 0.035f, 0.035f, 1.0f});
    fill_round_rect(1459.0f, 73.0f, 1516.0f, 130.0f, 12.0f, {0.035f, 0.035f, 0.035f, 1.0f});
    
    draw_texture(g_logo, 583.0f, 78.0f, 620.0f, 125.0f);
    draw_texture(g_search, 660.0f, 82.0f, 692.0f, 123.0f);
    draw_texture(g_close, 1400.0f, 80.0f, 1437.0f, 117.0f);
    draw_texture(g_toolbar_gear, 1468.0f, 77.0f, 1507.0f, 126.0f);
    stroke_line(659.0f, 101.0f, 683.0f, 101.0f, {0.40f, 0.40f, 0.42f, 1.0f}, 3.0f);
    stroke_line(671.0f, 89.0f, 671.0f, 113.0f, {0.40f, 0.40f, 0.42f, 1.0f}, 3.0f);

    fill_round_rect(573.0f, 143.0f, 782.0f, 199.0f, 11.0f, {0.035f, 0.035f, 0.035f, 1.0f});
    fill_round_rect(795.0f, 143.0f, 1004.0f, 199.0f, 11.0f, {0.035f, 0.035f, 0.035f, 1.0f});
    fill_round_rect(1017.0f, 143.0f, 1226.0f, 199.0f, 11.0f, {0.035f, 0.035f, 0.035f, 1.0f});
    fill_round_rect(1239.0f, 143.0f, 1447.0f, 199.0f, 11.0f, {0.035f, 0.035f, 0.035f, 1.0f});

    fill_round_rect(573.0f, 215.0f, 1516.0f, 563.0f, 13.0f, {0.035f, 0.035f, 0.035f, 1.0f});
    
    // КНОПКА WIN 8:0
    fill_round_rect(573.0f, 215.0f, 1516.0f, 280.0f, 13.0f, {0.8f, 0.1f, 0.1f, 1.0f}); // Красная кнопка
    if (is_touched && touch_x > 573 && touch_x < 1516 && touch_y > 215 && touch_y < 280) {
        g_win_requested = true; // Отправляем сигнал в main.cpp
        is_touched = false;
    }

    for (int row = 1; row < 5; ++row) {
        const float y = 250.0f + row * 69.0f;
        stroke_line(597.0f, y + 34.0f, 1493.0f, y + 34.0f, {0.16f, 0.16f, 0.17f, 1.0f}, 1.0f);
        draw_toggle(y);
    }
}

}  // namespace

extern "C" __attribute__((visibility("default"))) void menu_render(float width, float height) {
    if (width <= 0.0f || height <= 0.0f) return;
    draw_menu(width, height);
}

// Обработчик касаний (вызывается из main.cpp)
extern "C" __attribute__((visibility("default"))) void menu_on_touch(float x, float y, bool down) {
    touch_x = x * (1920.0f / 1080.0f); // Пересчет координат экрана под наш Viewport
    touch_y = y;
    is_touched = down;
}

extern "C" __attribute__((visibility("default"))) bool menu_check_win() {
    if (g_win_requested) {
        g_win_requested = false;
        return true;
    }
    return false;
}