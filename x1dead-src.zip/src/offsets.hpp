#pragma once
#include <cstdint>

// Офсеты от StandRise RE, адаптированные под сурс privetotglamura

// GameController (StandRise) -> 0x123C37C
#define OFF_GAMECONTROLLER_INSTANCE     0x123C37C
#define OFF_GAMECONTROLLER_PLAYERCTRL   0x200

// PlayerController
#define OFF_PC_TEAM                     0x49
#define OFF_PC_PHOTON_PLAYER            0x120
#define OFF_PC_PLAYER_ID                0x118
#define OFF_PC_AIM_CONTROLLER           0x50
#define OFF_PC_WEAPONRY                 0x58
#define OFF_PC_FPS_CAMERA               0xB8
#define OFF_PC_TRANSFORM                0xC8

// AimingData
#define OFF_AIM_AIMING_DATA             0x90
#define OFF_AIMING_PITCH                0x18
#define OFF_AIMING_YAW                  0x28
#define OFF_AIM_MIN_X                   0x58
#define OFF_AIM_MAX_X                   0x5C

// Photon / Room
#define OFF_PHOTON_GETROOM              0x18D80F0
#define OFF_ROOM_CUSTOM_PROPS           0x18
#define OFF_ROOM_SET_SCORE              0x1370124
#define OFF_ROOM_SET_ROUND              0x136F798
#define OFF_ROOM_SET_RC                 0x13712A0
#define OFF_ROOM_SET_TIME               0x136F67C
#define OFF_ROOM_SET_CUST               0x1570F1C

// Weaponry
#define OFF_WC_CURRENT_WEAPON           0x90
#define OFF_WC_PLAYER_CONTROLLER        0x50

// Здоровье
#define OFF_PLAYER_HEALTH_GET           0x15AE474
#define OFF_PLAYER_HEALTH_SET           0x15AE0C0

// Для ВХ (если используется)
#define OFF_PLAYER_OCCLUSION            0xB8
#define OFF_PLAYER_CHAR_VIEW            0x48
#define OFF_PLAYER_CHAR_LOD             0xF0