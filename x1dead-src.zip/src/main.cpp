#include "core.hpp"
#include <jni.h>
#include "hooking.hpp"
#include "../includes/imgui/imgui.h"
#include "../includes/imgui/backends/imgui_impl_opengl3.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

uintptr_t base = 0;
bool g_imgui_ready = false;
bool g_menu = false;

typedef EGLBoolean (*SwapFn)(EGLDisplay, EGLSurface);
SwapFn orig_swap = nullptr;

EGLBoolean hk_swap(EGLDisplay d, EGLSurface s) {
    if (!g_imgui_ready) {
        ImGui::CreateContext();
        ImGui::GetIO().IniFilename = nullptr;
        ImGui::StyleColorsDark();
        ImGui_ImplOpenGL3_Init("#version 300 es");
        g_imgui_ready = true;
        LOG("ImGui ready");
    }

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();

    ImGui::SetNextWindowPos(ImVec2(20, 200), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(60, 60), ImGuiCond_Always);
    ImGui::Begin("##btn", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBackground);
    if (ImGui::Button("X1", ImVec2(60, 60))) g_menu = !g_menu;
    ImGui::End();

    if (g_menu) {
        ImGui::Begin("by.x1dead", nullptr, ImGuiWindowFlags_NoCollapse);
        ImGui::Text("StandRise RE");
        ImGui::Separator();
        ImGui::Text("Menu is working!");
        ImGui::End();
    }

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    return orig_swap ? orig_swap(d, s) : EGL_FALSE;
}

void* thread_main(void*) {
    while (!base) {
        base = (uintptr_t)dlopen("libil2cpp.so", RTLD_LAZY | RTLD_NOLOAD);
        sleep(1);
    }
    LOG("il2cpp found at %p", (void*)base);

    void* h = dlopen("libEGL.so", RTLD_NOW);
    if (h) {
        void* target = dlsym(h, "eglSwapBuffers");
        if (target) {
            uintptr_t page_size = sysconf(_SC_PAGESIZE);
            uintptr_t page_start = (uintptr_t)target & ~(page_size - 1);
            mprotect((void*)page_start, page_size * 2, PROT_READ | PROT_WRITE | PROT_EXEC);
            
            uint8_t* orig = (uint8_t*)malloc(16);
            memcpy(orig, target, 16);
            orig_swap = (SwapFn)orig;

            uint32_t* p = (uint32_t*)target;
            p[0] = 0x58000050; 
            p[1] = 0xD61F0200;
            *(uint64_t*)((uintptr_t)target + 8) = (uint64_t)hk_swap;
            __builtin___clear_cache((char*)target, (char*)target + 16);

            LOG("EGL Hooked!");
        }
    }
    return nullptr;
}

extern "C" __attribute__((visibility("default"))) void payload_entry(void* base_addr) {
    (void)base_addr;
    pthread_t th;
    if (pthread_create(&th, nullptr, thread_main, nullptr) == 0)
        pthread_detach(th);
}